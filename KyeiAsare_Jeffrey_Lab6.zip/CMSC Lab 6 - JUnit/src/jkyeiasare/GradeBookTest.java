package jkyeiasare;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GradeBookTest {
	
	@Before
	public void setUp() throws Exception {
		GradeBook gr = new GradeBook(5);
		GradeBook h5 = new GradeBook(5);
		gr.addScore(7);
		gr.addScore(10);
		gr.addScore(3);
		h5.addScore(23);
		h5.addScore(1);
		h5.addScore(35);
	}

	@After
	public void tearDown() throws Exception {
			GradeBook gr = null;
			GradeBook h5 = null;
			h5 = null;
	}

	@Test
	public void testAddScore() {
		fail("Not yet implemented");
	}

	@Test
	public void testSum() {
		fail("Not yet implemented");
	}

	@Test
	public void testMinimum() {
		fail("Not yet implemented");
	}

	@Test
	public void testFinalScore() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetScoreSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
